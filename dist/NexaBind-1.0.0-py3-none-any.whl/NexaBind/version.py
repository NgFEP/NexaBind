
# THIS FILE IS GENERATED FROM NexaBind SETUP.PY
short_version = '1.0.0'
version = '1.0.0'
full_version = '1.0.0.dev-Unknown'
git_revision = 'Unknown'
release = False
NexaBind_library_path = r'C:/Program Files/NexaBind/lib'

if not release:
    version = full_version
